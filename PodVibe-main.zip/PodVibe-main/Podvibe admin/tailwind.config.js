/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/views/**/*.pug", "./public/**/*.js"],
  theme: {
    extend: {},
  },
  plugins: [],
};

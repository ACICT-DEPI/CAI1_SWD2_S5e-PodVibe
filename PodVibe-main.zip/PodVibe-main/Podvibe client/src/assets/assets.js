
import PodVibe from  './PodVibe.ico'

export const assets = {
    PodVibe
}

